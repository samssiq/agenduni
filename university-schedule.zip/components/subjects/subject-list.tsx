"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Plus, Search, Edit, Trash2, MapPin, User, Clock } from "lucide-react"
import { SubjectForm } from "./subject-form"
import Link from "next/link"

// Mock data - replace with actual API calls
const mockSubjects = [
  {
    id: 1,
    nome: "Cálculo II",
    sala: "Sala 201",
    professor: "Prof. Silva",
    horario: "Seg/Qua 14:00-16:00",
    avaliacoes: "P1: 8.5, P2: 7.0",
    faltas: 2,
    notas: 7.75,
    userId: 1,
  },
  {
    id: 2,
    nome: "Programação Orientada a Objetos",
    sala: "Lab 105",
    professor: "Prof. Santos",
    horario: "Ter/Qui 10:00-12:00",
    avaliacoes: "P1: 9.0, Projeto: 8.5",
    faltas: 0,
    notas: 8.75,
    userId: 1,
  },
  {
    id: 3,
    nome: "Banco de Dados",
    sala: "Sala 303",
    professor: "Prof. Oliveira",
    horario: "Sex 08:00-12:00",
    avaliacoes: "P1: 7.5",
    faltas: 1,
    notas: 7.5,
    userId: 1,
  },
]

export function SubjectList() {
  const [subjects, setSubjects] = useState(mockSubjects)
  const [searchTerm, setSearchTerm] = useState("")
  const [showForm, setShowForm] = useState(false)
  const [editingSubject, setEditingSubject] = useState<(typeof mockSubjects)[0] | null>(null)

  const filteredSubjects = subjects.filter(
    (subject) =>
      subject.nome.toLowerCase().includes(searchTerm.toLowerCase()) ||
      subject.professor.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  const handleAddSubject = (subjectData: any) => {
    const newSubject = {
      ...subjectData,
      id: Math.max(...subjects.map((s) => s.id)) + 1,
      userId: 1,
    }
    setSubjects([...subjects, newSubject])
    setShowForm(false)
  }

  const handleEditSubject = (subjectData: any) => {
    setSubjects(
      subjects.map((s) => (s.id === editingSubject?.id ? { ...subjectData, id: editingSubject.id, userId: 1 } : s)),
    )
    setEditingSubject(null)
    setShowForm(false)
  }

  const handleDeleteSubject = (id: number) => {
    setSubjects(subjects.filter((s) => s.id !== id))
  }

  const getGradeColor = (grade: number) => {
    if (grade >= 8) return "bg-green-100 text-green-800"
    if (grade >= 7) return "bg-yellow-100 text-yellow-800"
    return "bg-red-100 text-red-800"
  }

  const getAbsenceColor = (absences: number) => {
    if (absences === 0) return "bg-green-100 text-green-800"
    if (absences <= 2) return "bg-yellow-100 text-yellow-800"
    return "bg-red-100 text-red-800"
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Gerenciar Disciplinas</h1>
        <Button onClick={() => setShowForm(true)}>
          <Plus className="mr-2 h-4 w-4" />
          Nova Disciplina
        </Button>
      </div>

      <div className="flex items-center gap-4">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Buscar disciplinas..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredSubjects.map((subject) => (
          <Card key={subject.id} className="hover:shadow-md transition-shadow">
            <CardHeader className="pb-3">
              <div className="flex items-start justify-between">
                <CardTitle className="text-lg text-balance">
                  <Link href={`/subjects/${subject.id}`} className="hover:text-primary">
                    {subject.nome}
                  </Link>
                </CardTitle>
                <div className="flex gap-1">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => {
                      setEditingSubject(subject)
                      setShowForm(true)
                    }}
                  >
                    <Edit className="h-4 w-4" />
                  </Button>
                  <Button variant="ghost" size="sm" onClick={() => handleDeleteSubject(subject.id)}>
                    <Trash2 className="h-4 w-4 text-destructive" />
                  </Button>
                </div>
              </div>
            </CardHeader>

            <CardContent className="space-y-3">
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <MapPin className="h-4 w-4" />
                <span>{subject.sala}</span>
              </div>

              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <User className="h-4 w-4" />
                <span>{subject.professor}</span>
              </div>

              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Clock className="h-4 w-4" />
                <span>{subject.horario}</span>
              </div>

              <div className="flex items-center justify-between pt-2">
                <div className="flex flex-col gap-1">
                  <Badge className={getGradeColor(subject.notas)}>Nota: {subject.notas.toFixed(1)}</Badge>
                  <Badge className={getAbsenceColor(subject.faltas)}>Faltas: {subject.faltas}</Badge>
                </div>
              </div>

              <div className="text-xs text-muted-foreground">
                <strong>Avaliações:</strong> {subject.avaliacoes}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredSubjects.length === 0 && (
        <div className="text-center py-12">
          <p className="text-muted-foreground">Nenhuma disciplina encontrada.</p>
        </div>
      )}

      {showForm && (
        <SubjectForm
          subject={editingSubject}
          onSubmit={editingSubject ? handleEditSubject : handleAddSubject}
          onCancel={() => {
            setShowForm(false)
            setEditingSubject(null)
          }}
        />
      )}
    </div>
  )
}
