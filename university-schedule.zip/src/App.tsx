import { Routes, Route, Navigate } from "react-router-dom"
import { Toaster } from "@/components/ui/sonner"
import LoginPage from "@/pages/LoginPage"
import RegisterPage from "@/pages/RegisterPage"
import DashboardPage from "@/pages/DashboardPage"
import SubjectsPage from "@/pages/SubjectsPage"
import SubjectDetailsPage from "@/pages/SubjectDetailsPage"
import RemindersPage from "@/pages/RemindersPage"
import ContactsPage from "@/pages/ContactsPage"
import MaterialsPage from "@/pages/MaterialsPage"

function App() {
  return (
    <div className="min-h-screen bg-background">
      <Routes>
        <Route path="/" element={<Navigate to="/login" replace />} />
        <Route path="/login" element={<LoginPage />} />
        <Route path="/register" element={<RegisterPage />} />
        <Route path="/dashboard" element={<DashboardPage />} />
        <Route path="/subjects" element={<SubjectsPage />} />
        <Route path="/subjects/:id" element={<SubjectDetailsPage />} />
        <Route path="/reminders" element={<RemindersPage />} />
        <Route path="/contacts" element={<ContactsPage />} />
        <Route path="/materials" element={<MaterialsPage />} />
      </Routes>
      <Toaster />
    </div>
  )
}

export default App
