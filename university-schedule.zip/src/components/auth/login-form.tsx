"use client"

import type React from "react"
import { useState } from "react"
import { useNavigate, Link } from "react-router-dom"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { toast } from "sonner"

export function LoginForm() {
  const [email, setEmail] = useState("")
  const [senha, setSenha] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const navigate = useNavigate()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    try {
      // Mock authentication - replace with actual API call
      if (email && senha) {
        // Simulate API delay
        await new Promise((resolve) => setTimeout(resolve, 1000))

        // Store user session (mock)
        localStorage.setItem("user", JSON.stringify({ email, nome: "Usuário" }))

        toast.success("Login realizado com sucesso!", {
          description: "Redirecionando para o dashboard...",
        })

        navigate("/dashboard")
      } else {
        throw new Error("Email e senha são obrigatórios")
      }
    } catch (error) {
      toast.error("Erro no login", {
        description: error instanceof Error ? error.message : "Tente novamente",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="email">Email</Label>
        <Input
          id="email"
          type="email"
          placeholder="seu@email.com"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="senha">Senha</Label>
        <Input
          id="senha"
          type="password"
          placeholder="Sua senha"
          value={senha}
          onChange={(e) => setSenha(e.target.value)}
          required
        />
      </div>

      <Button type="submit" className="w-full" disabled={isLoading}>
        {isLoading ? "Entrando..." : "Entrar"}
      </Button>

      <div className="text-center text-sm">
        <span className="text-muted-foreground">Não tem uma conta? </span>
        <Link to="/register" className="text-primary hover:underline">
          Cadastre-se
        </Link>
      </div>
    </form>
  )
}
